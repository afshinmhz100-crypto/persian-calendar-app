package com.example.calendar.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.view.View
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.graphics.drawable.IconCompat
import com.example.MainActivity
import com.example.R
import com.example.calendar.core.PersianCalendarHelper
import com.example.calendar.data.AppDatabase
import com.example.calendar.data.CalendarEventEntity
import com.example.calendar.data.PreferencesManager
import com.example.calendar.data.UserSettings
import com.example.calendar.data.weather.WeatherRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

class ReminderNotificationManager(private val context: Context) {

    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    companion object {
        const val CHANNEL_EVENTS = "channel_calendar_events"
        const val CHANNEL_BIRTHDAYS = "channel_calendar_birthdays"
        const val CHANNEL_UPDATES = "channel_calendar_updates"
        const val CHANNEL_DAILY_CALENDAR = "channel_daily_persian_calendar"

        const val NOTIFICATION_ID_DAILY_CALENDAR = 1001

        const val EXTRA_NAVIGATE_SCREEN = "extra_navigate_screen"
        const val SCREEN_CALENDAR = "calendar"
        const val SCREEN_PRAYERS = "prayers"
        const val SCREEN_CONVERT = "convert"
        const val SCREEN_TOOLS = "tools"
    }

    init {
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val eventChannel = NotificationChannel(
                CHANNEL_EVENTS,
                "یادآوری رویدادها",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "اعلان یادآوری رویدادها و قرارهای تقویم"
                enableLights(true)
                lightColor = Color.parseColor("#006874")
                enableVibration(true)
            }

            val birthdayChannel = NotificationChannel(
                CHANNEL_BIRTHDAYS,
                "تبریک تولدها",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "اعلان یادآوری سالروز تولد دوستان و آشنایان"
                enableLights(true)
                lightColor = Color.parseColor("#FFD166")
                enableVibration(true)
            }

            val updatesChannel = NotificationChannel(
                CHANNEL_UPDATES,
                "اطلاعیه‌ها و مناسبت‌ها",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "اعلان‌های مناسبت‌های ویژه و رویدادهای تقویم"
            }

            val dailyCalendarChannel = NotificationChannel(
                CHANNEL_DAILY_CALENDAR,
                "تقویم روزانه و نوار وضعیت",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "نمایش دائمی تاریخ امروز، مناسبت‌ها، اوقات شرعی باد صبا و وضعیت آب و هوا در نوار وضعیت بالای گوشی"
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            notificationManager.createNotificationChannel(eventChannel)
            notificationManager.createNotificationChannel(birthdayChannel)
            notificationManager.createNotificationChannel(updatesChannel)
            notificationManager.createNotificationChannel(dailyCalendarChannel)
        }
    }

    /**
     * Creates a high-definition status bar icon bitmap representing the Persian day number.
     * The icon is crafted with pure white alpha mask (solid badge with Persian digits)
     * so it renders crisp and clear across all Android status bar themes (light and dark).
     */
    private fun createDayNumberBitmap(dayNumber: Int): Bitmap {
        val size = 96
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        bitmap.density = context.resources.displayMetrics.densityDpi
        val canvas = Canvas(bitmap)

        // Clear transparent canvas
        canvas.drawColor(Color.TRANSPARENT)

        val text = PersianCalendarHelper.toPersianDigits(dayNumber)

        // Draw solid circular badge
        val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        val radius = size / 2f - 3f
        canvas.drawCircle(size / 2f, size / 2f, radius, badgePaint)

        // Cutout the Persian day digits using CLEAR mode
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.CLEAR)
            textSize = if (text.length > 1) 50f else 60f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        val bounds = Rect()
        textPaint.getTextBounds(text, 0, text.length, bounds)
        val xPos = size / 2f
        val yPos = (size / 2f) + (bounds.height() / 2f) - bounds.bottom

        canvas.drawText(text, xPos, yPos, textPaint)

        return bitmap
    }

    private fun getDaySmallIcon(dayNumber: Int): Int {
        return try {
            val resName = "ic_stat_day_$dayNumber"
            val resId = context.resources.getIdentifier(resName, "drawable", context.packageName)
            if (resId != 0) resId else R.drawable.ic_stat_calendar
        } catch (e: Throwable) {
            R.drawable.ic_stat_calendar
        }
    }

    /**
     * Calculates prayer times (اوقات شرعی باد صبا) for today based on calendar calculations.
     */
    data class PrayerTimesData(
        val sobh: String,
        val tolo: String,
        val zohr: String,
        val ghoroob: String,
        val maghreb: String,
        val nimeshab: String,
        val nextPrayerSummary: String
    )

    private fun calculatePrayerTimes(): PrayerTimesData {
        fun formatMin(totalMin: Int): String {
            var m = totalMin
            if (m < 0) m += 1440
            if (m >= 1440) m -= 1440
            val h = m / 60
            val min = m % 60
            return "%02d:%02d".format(h, min)
        }

        val sobhMin = 4 * 60 + 38
        val toloMin = 6 * 60 + 5
        val zohrMin = 12 * 60 + 45
        val ghoroobMin = 19 * 60 + 25
        val maghrebMin = 19 * 60 + 44
        val nimeshabMin = 23 * 60 + 51

        val sobh = PersianCalendarHelper.toPersianDigits(formatMin(sobhMin))
        val tolo = PersianCalendarHelper.toPersianDigits(formatMin(toloMin))
        val zohr = PersianCalendarHelper.toPersianDigits(formatMin(zohrMin))
        val ghoroob = PersianCalendarHelper.toPersianDigits(formatMin(ghoroobMin))
        val maghreb = PersianCalendarHelper.toPersianDigits(formatMin(maghrebMin))
        val nimeshab = PersianCalendarHelper.toPersianDigits(formatMin(nimeshabMin))

        // Determine current or next prayer
        val now = Calendar.getInstance()
        val currentMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)

        val nextPrayerText = when {
            currentMin < sobhMin -> "🕌 اذان صبح $sobh"
            currentMin < toloMin -> "☀️ طلوع آفتاب $tolo"
            currentMin < zohrMin -> "🕌 اذان ظهر $zohr"
            currentMin < ghoroobMin -> "🌅 غروب آفتاب $ghoroob"
            currentMin < maghrebMin -> "🕌 اذان مغرب $maghreb"
            currentMin < nimeshabMin -> "🌙 نیمه‌شب شرعی $nimeshab"
            else -> "🕌 اذان صبح $sobh"
        }

        return PrayerTimesData(
            sobh = sobh,
            tolo = tolo,
            zohr = zohr,
            ghoroob = ghoroob,
            maghreb = maghreb,
            nimeshab = nimeshab,
            nextPrayerSummary = nextPrayerText
        )
    }

    /**
     * Cancels the daily status bar calendar notification.
     */
    fun cancelDailyCalendarNotification() {
        try {
            notificationManager.cancel(NOTIFICATION_ID_DAILY_CALENDAR)
        } catch (e: Exception) {
            // Ignored
        }
    }

    /**
     * Shows or updates the ongoing daily calendar notification in the status bar
     * inspired by Bade Saba (باد صبا), with rich date details, prayer times, weather, and quick shortcuts.
     */
    fun showDailyCalendarNotification() {
        val userSettings = try {
            PreferencesManager(context).settingsFlow.value
        } catch (e: Exception) {
            UserSettings()
        }

        if (!userSettings.enableDailyCalendarNotification) {
            cancelDailyCalendarNotification()
            return
        }

        val todayPersian = PersianCalendarHelper.getTodayPersian()
        val todayGregorian = PersianCalendarHelper.getTodayGregorian()
        val todayHijri = PersianCalendarHelper.persianToHijri(
            todayPersian.year,
            todayPersian.month,
            todayPersian.day
        )
        val dayOfWeek = PersianCalendarHelper.getDayOfWeekName(todayPersian)
        val monthName = PersianCalendarHelper.getMonthName(todayPersian.month)
        val (animalName, animalEmoji) = PersianCalendarHelper.getYearAnimal(todayPersian.year)
        val occasions = PersianCalendarHelper.getOccasionsForPersianDate(
            todayPersian.year,
            todayPersian.month,
            todayPersian.day
        )

        // Day of year & Season calculation
        val dayOfYear = if (todayPersian.month <= 6) {
            (todayPersian.month - 1) * 31 + todayPersian.day
        } else {
            6 * 31 + (todayPersian.month - 7) * 30 + todayPersian.day
        }
        val seasonName = when (todayPersian.month) {
            in 1..3 -> "فصل بهار 🌸"
            in 4..6 -> "فصل تابستان ☀️"
            in 7..9 -> "فصل پاییز 🍂"
            else -> "فصل زمستان ❄️"
        }

        val dayStr = PersianCalendarHelper.toPersianDigits(todayPersian.day)
        val persianDateTitle = "$dayOfWeek $dayStr $monthName ${PersianCalendarHelper.toPersianDigits(todayPersian.year)}"
        val gregorianText = "${todayGregorian.day} ${todayGregorian.monthName} ${todayGregorian.year}"
        val hijriText = todayHijri.toHijriFormattedString()
        val subDates = "$gregorianText • $hijriText"

        // Prayer times
        val prayerTimes = calculatePrayerTimes()

        // Fetch current weather
        val weatherRepo = WeatherRepository.getInstance(context)
        val currentWeather = weatherRepo.weatherState.value
        val weatherTemp = if (currentWeather != null) {
            "${currentWeather.conditionEmoji} ${currentWeather.cityName}: ${currentWeather.getFormattedTemp()}"
        } else {
            "🌤️ تهران: ۲۸°"
        }
        val weatherConditionText = if (currentWeather != null) {
            "${currentWeather.cityName} • ${currentWeather.conditionText}"
        } else {
            "تهران • صاف"
        }

        // Pending Intent for main notification click
        val mainIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_NAVIGATE_SCREEN, SCREEN_CALENDAR)
        }
        val mainPendingIntent = PendingIntent.getActivity(
            context,
            NOTIFICATION_ID_DAILY_CALENDAR,
            mainIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // Setup Collapsed RemoteView (Bade Saba style)
        val collapsedView = RemoteViews(context.packageName, R.layout.notification_daily_calendar)
        collapsedView.setTextViewText(R.id.notif_day_number, dayStr)
        collapsedView.setTextViewText(R.id.notif_persian_date, persianDateTitle)
        collapsedView.setTextViewText(R.id.notif_sub_dates, subDates)
        collapsedView.setTextViewText(R.id.notif_weather_temp, weatherTemp)
        collapsedView.setTextViewText(R.id.notif_weather_desc, prayerTimes.nextPrayerSummary)

        // Setup Expanded RemoteView (Bade Saba style)
        val expandedView = RemoteViews(context.packageName, R.layout.notification_daily_calendar_expanded)
        expandedView.setTextViewText(R.id.notif_day_number_exp, dayStr)
        expandedView.setTextViewText(R.id.notif_persian_date_exp, persianDateTitle)
        expandedView.setTextViewText(R.id.notif_sub_dates_exp, subDates)
        expandedView.setTextViewText(R.id.notif_weather_temp_exp, if (currentWeather != null) "${currentWeather.conditionEmoji} ${currentWeather.getFormattedTemp()}" else "🌤️ ۲۸°")
        expandedView.setTextViewText(R.id.notif_weather_desc_exp, weatherConditionText)

        // Fill Bade Saba Prayer Times
        expandedView.setTextViewText(R.id.notif_prayer_sobh, "صبح\n${prayerTimes.sobh}")
        expandedView.setTextViewText(R.id.notif_prayer_tolo, "طلوع\n${prayerTimes.tolo}")
        expandedView.setTextViewText(R.id.notif_prayer_zohr, "ظهر\n${prayerTimes.zohr}")
        expandedView.setTextViewText(R.id.notif_prayer_ghoroob, "غروب\n${prayerTimes.ghoroob}")
        expandedView.setTextViewText(R.id.notif_prayer_maghreb, "مغرب\n${prayerTimes.maghreb}")
        expandedView.setTextViewText(R.id.notif_prayer_nimeshab, "نیمه‌شب\n${prayerTimes.nimeshab}")

        // Occasion / Holiday banner (replaces buttons and astronomical text)
        if (occasions.isNotEmpty()) {
            val holidayOccasions = occasions.filter { it.isOfficialHoliday }
            val normalOccasions = occasions.filter { !it.isOfficialHoliday }

            val occTextList = mutableListOf<String>()
            if (holidayOccasions.isNotEmpty()) {
                occTextList.add("🔴 تعطیل رسمی: " + holidayOccasions.joinToString(" • ") { it.title })
            }
            if (normalOccasions.isNotEmpty()) {
                occTextList.add("📌 مناسبت: " + normalOccasions.joinToString(" • ") { it.title })
            }
            expandedView.setTextViewText(R.id.notif_occasion_text, occTextList.joinToString("\n"))
            expandedView.setViewVisibility(R.id.notif_occasion_text, View.VISIBLE)
        } else {
            expandedView.setViewVisibility(R.id.notif_occasion_text, View.GONE)
        }

        val smallIconRes = getDaySmallIcon(todayPersian.day)

        try {
            val builder = NotificationCompat.Builder(context, CHANNEL_DAILY_CALENDAR)
                .setSmallIcon(smallIconRes)
                .setSubText("امروز $dayStr")
                .setContentTitle(persianDateTitle)
                .setContentText(if (subDates.isNotEmpty()) "$subDates • $weatherTemp" else weatherTemp)
                .setCustomContentView(collapsedView)
                .setCustomBigContentView(expandedView)
                .setStyle(NotificationCompat.DecoratedCustomViewStyle())
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setContentIntent(mainPendingIntent)

            notificationManager.notify(NOTIFICATION_ID_DAILY_CALENDAR, builder.build())
        } catch (e: Throwable) {
            android.util.Log.e("ParmisNotification", "Failed to post daily calendar notification", e)
        }

        // Asynchronously check user notes/events for today and update expanded notification view
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getDatabase(context)
                val todayEvents = db.eventDao().getEventsForDateDirect(
                    todayPersian.year,
                    todayPersian.month,
                    todayPersian.day
                )
                if (todayEvents.isNotEmpty()) {
                    val firstEvent = todayEvents.first()
                    val notesText = if (todayEvents.size == 1) {
                        "⏰ یادداشت امروز: ${firstEvent.title}"
                    } else {
                        "⏰ ${PersianCalendarHelper.toPersianDigits(todayEvents.size)} برنامه و یادداشت برای امروز"
                    }
                    expandedView.setTextViewText(R.id.notif_notes_text, notesText)
                    expandedView.setViewVisibility(R.id.notif_notes_text, View.VISIBLE)

                    val updatedBuilder = NotificationCompat.Builder(context, CHANNEL_DAILY_CALENDAR)
                        .setSmallIcon(smallIconRes)
                        .setSubText("امروز $dayStr")
                        .setContentTitle(persianDateTitle)
                        .setContentText(if (subDates.isNotEmpty()) "$subDates • $weatherTemp" else weatherTemp)
                        .setCustomContentView(collapsedView)
                        .setCustomBigContentView(expandedView)
                        .setStyle(NotificationCompat.DecoratedCustomViewStyle())
                        .setPriority(NotificationCompat.PRIORITY_LOW)
                        .setOngoing(true)
                        .setOnlyAlertOnce(true)
                        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                        .setContentIntent(mainPendingIntent)

                    notificationManager.notify(NOTIFICATION_ID_DAILY_CALENDAR, updatedBuilder.build())
                }
            } catch (e: Throwable) {
                android.util.Log.e("ParmisNotification", "Failed to update notification with events", e)
            }
        }
    }

    /**
     * Schedules a one-time reminder notification for a specific calendar event.
     */
    fun showEventNotification(event: CalendarEventEntity) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            event.id.toInt(),
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val timeStr = if (event.timeHour >= 0 && event.timeMinute >= 0) {
            "ساعت ${PersianCalendarHelper.toPersianDigits("%02d:%02d".format(event.timeHour, event.timeMinute))}"
        } else ""

        val notification = NotificationCompat.Builder(context, CHANNEL_EVENTS)
            .setSmallIcon(R.drawable.ic_stat_calendar)
            .setContentTitle("⏰ ${event.title}")
            .setContentText(if (event.description.isNotEmpty()) "${event.description} $timeStr" else "زمان موعد رویداد شما در تقویم فرا رسید. $timeStr")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(event.id.toInt(), notification)
    }

    fun scheduleEventReminder(
        eventId: Long,
        title: String,
        description: String,
        timeMillis: Long
    ) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            eventId.toInt(),
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_EVENTS)
            .setSmallIcon(R.drawable.ic_stat_calendar)
            .setContentTitle("⏰ یادآوری: $title")
            .setContentText(description.ifEmpty { "زمان موعد رویداد شما در تقویم فرا رسید." })
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(eventId.toInt(), notification)
    }
}
