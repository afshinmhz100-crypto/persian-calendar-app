package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.calendar.data.ThemeMode
import com.example.calendar.notifications.ReminderNotificationManager
import com.example.calendar.ui.CalendarViewModel
import com.example.calendar.ui.MainScreen
import com.example.calendar.ui.MainTab
import com.example.calendar.widget.PersianCalendarWidgetProvider
import com.example.ui.theme.PersianCalendarTheme

class MainActivity : ComponentActivity() {

    private val calendarViewModel: CalendarViewModel by viewModels()

    private val requestNotificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
            try {
                if (isGranted) {
                    ReminderNotificationManager(this).showDailyCalendarNotification()
                }
            } catch (e: Throwable) {
                // Safeguard
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Handle navigation intent from notification if present
        handleNotificationNavigation(intent)

        // Request POST_NOTIFICATIONS runtime permission on Android 13+ (API 33+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        // Update widget on app start and update status bar daily notification
        try {
            PersianCalendarWidgetProvider.sendUpdateBroadcast(this)
            ReminderNotificationManager(this).showDailyCalendarNotification()
        } catch (e: Throwable) {
            // Widget / notification safeguard
        }

        setContent {
            val userSettings by calendarViewModel.userSettings.collectAsStateWithLifecycle()

            val isDark = when (userSettings.themeMode) {
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
            }

            PersianCalendarTheme(
                themeStyle = userSettings.theme,
                darkTheme = isDark
            ) {
                val currentDensity = LocalDensity.current
                val scale = userSettings.fontSizeScale.coerceIn(0.75f, 1.4f)
                val customDensity = Density(
                    density = currentDensity.density,
                    fontScale = currentDensity.fontScale * scale
                )

                // Persian is an RTL language - provide RTL layout direction and font scale
                CompositionLocalProvider(
                    LocalLayoutDirection provides LayoutDirection.Rtl,
                    LocalDensity provides customDensity
                ) {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        MainScreen(viewModel = calendarViewModel)
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNotificationNavigation(intent)
    }

    private fun handleNotificationNavigation(intent: Intent?) {
        val screen = intent?.getStringExtra(ReminderNotificationManager.EXTRA_NAVIGATE_SCREEN) ?: return
        when (screen) {
            ReminderNotificationManager.SCREEN_CALENDAR,
            ReminderNotificationManager.SCREEN_PRAYERS -> {
                calendarViewModel.selectTab(MainTab.CALENDAR)
            }
            ReminderNotificationManager.SCREEN_CONVERT,
            ReminderNotificationManager.SCREEN_TOOLS -> {
                calendarViewModel.selectTab(MainTab.CONVERTER)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            PersianCalendarWidgetProvider.sendUpdateBroadcast(this)
            ReminderNotificationManager(this).showDailyCalendarNotification()
        } catch (e: Throwable) {
            // Widget / notification update safeguard
        }
    }
}
