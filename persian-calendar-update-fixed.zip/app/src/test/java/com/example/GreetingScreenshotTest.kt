package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.calendar.core.PersianCalendarHelper
import com.example.calendar.data.AppThemeStyle
import com.example.calendar.ui.MonthHeader
import com.example.ui.theme.PersianCalendarTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class GreetingScreenshotTest {

    @get:Rule val composeTestRule = createComposeRule()

    @Test
    fun greeting_screenshot() {
        composeTestRule.setContent {
            PersianCalendarTheme(themeStyle = AppThemeStyle.TURQUOISE) {
                MonthHeader(
                    year = 1404,
                    month = 1,
                    isViewingToday = true,
                    isDark = false,
                    onNext = {},
                    onPrev = {},
                    onJumpToday = {}
                )
            }
        }

        composeTestRule.onRoot().assertExists()
    }
}
