package com.example

import com.example.calendar.core.PersianCalendarHelper
import com.example.calendar.core.PersianDate
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testPersianToGregorianConversions() {
        // Test 1 Farvardin 1404 -> 21 March 2025
        val g1 = PersianCalendarHelper.persianToGregorian(1404, 1, 1)
        assertEquals(2025, g1.year)
        assertEquals(3, g1.month)
        assertEquals(21, g1.day)

        // Test End of year / Esfand 29/30
        val g2 = PersianCalendarHelper.persianToGregorian(1404, 12, 29)
        assertEquals(2026, g2.year)
        assertEquals(3, g2.month)
        assertEquals(20, g2.day)

        // Test Dey 10 (Around Dec 31 / Jan 1 boundary)
        val g3 = PersianCalendarHelper.persianToGregorian(1404, 10, 10)
        assertEquals(2025, g3.year)
        assertEquals(12, g3.month)
        assertEquals(31, g3.day)

        // Test Day of week calculations across months
        for (m in 1..12) {
            val pDate = PersianDate(1405, m, 1)
            val dow = PersianCalendarHelper.getDayOfWeekIndex(pDate)
            assertTrue(dow in 0..6)
            val dowName = PersianCalendarHelper.getDayOfWeekName(pDate)
            assertTrue(dowName.isNotEmpty())
        }
    }

    @Test
    fun testRoundTripDateConversions() {
        for (m in 1..12) {
            val daysInMonth = PersianCalendarHelper.getDaysInPersianMonth(1405, m)
            for (d in 1..daysInMonth) {
                val g = PersianCalendarHelper.persianToGregorian(1405, m, d)
                val p = PersianCalendarHelper.gregorianToPersian(g.year, g.month, g.day)
                assertEquals("Failed round-trip for 1405/$m/$d", 1405, p.year)
                assertEquals("Failed round-trip for 1405/$m/$d", m, p.month)
                assertEquals("Failed round-trip for 1405/$m/$d", d, p.day)
            }
        }
    }
}

